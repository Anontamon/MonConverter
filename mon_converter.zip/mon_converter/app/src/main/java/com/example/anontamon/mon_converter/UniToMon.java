package com.example.anontamon.mon_converter;

public class UniToMon {

	public static String uni2mon(String input_text) {
		String output_text = input_text;
		output_text = output_text.replaceAll("\\u104e\\u1004\\u103a\\u1038",
				"\u104e");
		output_text = output_text.replaceAll("\\u105a", "\u1004");// nga
		output_text = output_text.replaceAll("\\u102b\\u103a", "\u105a");
		output_text = output_text.replaceAll("\\u102b\\u103a", "\u102b\u103a");
		output_text = output_text.replaceAll("\\u102d\\u1036", "\u108e");
		output_text = output_text.replaceAll("\\u102d\\u1032", "\u1099");
		output_text = output_text.replaceAll("\\u103f", "\u1086");
		output_text = output_text.replaceAll("\\u105b", "\u1007\u103b"); // jha
		output_text = output_text.replaceAll("\\u105c", "\u1050"); // bba
		output_text = output_text.replaceAll("\\u105d", "\u1022"); // bbe
		output_text = output_text.replaceAll("\\u1039\\u1010\\u103d", "\u1096");
		output_text = output_text.replaceAll("\\u105f", "\u103f"); // ma
		output_text = output_text.replaceAll("\\u1060", "\u105c"); // la
		output_text = output_text.replaceAll("\\u102d\\u102f\\u1032",
				"\u1099\u102f"); // iai
		output_text = output_text.replaceAll("\\u1033", "\u1098"); // ii
		output_text = output_text.replaceAll("\\u1035", "\u109d"); // e
		output_text = output_text.replaceAll("\\u1034", "\u1035"); // o
		output_text = output_text.replaceAll("\\u109d", "\u109d"); // e
		output_text = output_text.replaceAll("\\u105e", "\u105e"); // na
		output_text = output_text.replaceAll("\\u103e", "\u103e"); // na
		output_text = output_text.replaceAll("\\u105a", "\u105a");// nga
		output_text = output_text.replaceAll("\\u1004", "\u1004");// nga
		output_text = output_text.replaceAll("\\u1034", "\u1034"); // o
		output_text = output_text.replaceAll("\\u1035", "\u1035"); // e
		output_text = output_text.replaceAll("\\u105e", "\u105e"); // na
		output_text = output_text.replaceAll("\\u103e", "\u103e"); // ha
		output_text = output_text.replaceAll("(?<=\\u102f)\\u1037", "\u1094");
		output_text = output_text.replaceAll("(?<=\\u102f\\u1036)\\u1037",
				"\u1094");
		output_text = output_text.replaceAll("(?<=\\u1030)\\u1037", "\u1094");
		output_text = output_text.replaceAll("(?<=\\u1030\\u1036)\\u1037",
				"\u1094");
		output_text = output_text.replaceAll("(?<=\\u1014)\\u1037", "\u1094");
		output_text = output_text.replaceAll(
				"(?<=\\u1014[\\u103a\\u1032])\\u1037", "\u1094");
		output_text = output_text.replaceAll("(?<=\\u103b)\\u1037", "\u1095");
		output_text = output_text.replaceAll(
				"(?<=\\u103b[\\u1032\\u1036])\\u1037", "\u1095");
		output_text = output_text.replaceAll("(?<=\\u103d)\\u1037", "\u1095");
		output_text = output_text.replaceAll("(?<=\\u103d[\\u1032])\\u1037",
				"\u1095");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u103b\\u103c\\u103d\\u103e\\u103f\\u105c\\u105e])\\u102f",
						"\u1033");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u103b\\u103c\\u103d\\u103e\\u103f\\u105c\\u105e][\\u102d\\u102e\\u1032-\\u1035\\u1036\\u109d\\u1099])\\u102f",
						"\u1033");
		output_text = output_text
				.replaceAll(
						"(?<=(\\u1039[\\u1000-\\u1021\\u1050\\u105a\\u105c\\u105e]))\\u102f",
						"\u1033");
		output_text = output_text
				.replaceAll(
						"(?<=(\\u1039[\\u1000-\\u1021\\u1050\\u105a\\u105c\\u105e])[\\u102d\\u102e\\u1032-\\u1035\\u1036\\u109d\\u1099])\\u102f",
						"\u1033");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u100a-\\u100c\\u100d\\u1020\\u1022\\u1025\\u1029])\\u102f",
						"\u1033");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u100a\\u100c\\u100d\\u1020\\u1022\\u1025\\u1029][\\u102d\\u102e\\u1032-\\u1035\\u1036\\u109d\\u1099])\\u102f",
						"\u1033");
		output_text = output_text.replaceAll(
				"(?<=[\\u103b\\u103c\\u103e\\u103f\\u105c\\u105e])\\u1030",
				"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u103b\\u103c\\u103e\\u103f\\u105c\\u105e][\\u103d])\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u103b\\u103c\\u103d\\u103f\\u105c\\u105e][\\u103e])\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u103b\\u103c-\\u103e\\u103f\\u105c\\u105e][\\u102d\\u102e\\u1032-\\u1035\\u1036\\u109d])\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u103b\\u103c-\\u103e\\u103f\\u105c\\u105e][\\u103d][\\u103e])\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u103b\\u103c-\\u103e\\u103f\\u105c\\u105e][\\u103d][\\u102d\\u102e\\u1032-\\u1035\\u1036\\u109d])\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u103b\\u103c-\\u103e\\u103f\\u105c\\u105e][\\u103e][\\u102d\\u1036])\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u103b\\u103c-\\u103e\\u103f\\u105c\\u105e][\\u103d][\\u103e][\\u102d\\u102e\\u1032-\\u1035\\u1036\\u109d])\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=(\\u1039[\\u1000-\\u1021\\u1050\\u105a\\u105c\\u105e]))\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=(\\u1039[\\u1000-\\u1021\\u1050\\u105a\\u105c\\u105e])[\\u102d\\u102e\\u1032-\\u1035\\u1036\\u109d])\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u100a-\\u100c\\u100d\\u1020\\u1022\\u1025\\u1029])\\u1030",
						"\u1034");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u100a-\\u100c\\u1020\\u1025\\u1029][\\u102d\\u102e\\u1032-\\u1035\\u1036\\u109d])\\u1030",
						"\u1034");
		output_text = output_text.replaceAll("(?<=\\u103c)\\u103e", "\u1087");
		output_text = output_text.replaceAll("\\u1009(?=[\\u103a])", "\u1025");
		output_text = output_text.replaceAll(
				"\\u1009(?=\\u1039[\\u1000-\\u1021])", "\u106A");
		output_text = output_text
				.replaceAll(
						"([\\u1000-\\u1021\\u1022\\u1029\\u1050\\u105a\\u105c\\u1086])((?:\\u1039[\\u1000-\\u1021\\u1050\\u105a-\\u105c\\u105e\\u1096])?)((?:[\\u103b-\\u103e\\u105e\\u103f\\u105c\\u1087]*)?)\\u1031",
						"\u1031$1$2$3");
		output_text = output_text
				.replaceAll(
						"([\\u1000-\\u1021\\u1029\\u1050])((?:\\u1039[\\u1000-\\u1021\\u1000-\\u1021])?)(\\u103c)",
						"$3$1$2");
		output_text = output_text.replaceAll("\\u1004\\u103a\\u1039", "\u1064");
		output_text = output_text
				.replaceAll(
						"(\\u1064)((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021\\u1050\\u105a\\u105c])\\u102d",
						"$2$3$4\u108b");
		output_text = output_text
				.replaceAll(
						"(\\u1064)((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021\\u1050\\u105a\\u105c])\\u102e",
						"$2$3$4\u108c");
		output_text = output_text
				.replaceAll(
						"(\\u1064)((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021\\u1050\\u105a\\u105c])\\u1036",
						"$2$3$4\u108d");
		output_text = output_text
				.replaceAll(
						"(\\u1064)((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021\\u1050\\u105a\\u105c])\\u1033",
						"$2$3$4\u109a");
		output_text = output_text
				.replaceAll(
						"(\\u1064)((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021\\u1050\\u105a\\u105c])",
						"$2$3$4\u1064");
		output_text = output_text.replaceAll(
				"\\u100a(?=[\\u1039\\u102f\\u1030])", "\u106b");
		output_text = output_text.replaceAll("\\u100a", "\u100a");
		output_text = output_text.replaceAll("\\u101b(?=[\\u102f\\u1030])",
				"\u1090");
		output_text = output_text.replaceAll("\\u101b", "\u101b");
		output_text = output_text
				.replaceAll(
						"\\u1014(?=[\\u1039\\u103b\\u103d\\u103e\\u102f\\u1030\\u1096])",
						"\u108f"); // new
		output_text = output_text.replaceAll("\\u1014", "\u1014");
		output_text = output_text.replaceAll("\\u1039\\u1000", "\u1060");
		output_text = output_text.replaceAll("\\u1039\\u1001", "\u1061");
		output_text = output_text.replaceAll("\\u1039\\u1002", "\u1062");
		output_text = output_text.replaceAll("\\u1039\\u1003", "\u1063");
		output_text = output_text.replaceAll("\\u1039\\u1004", "\u105b");
		output_text = output_text.replaceAll("\\u1039\\u1005", "\u1065");
		output_text = output_text.replaceAll("\\u1039\\u1006", "\u1066");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u1001\\u1002\\u1004\\u1005\\u1007\\u1012\\u1013\\u108f\\u1015\\u1016\\u1017\\u1019\\u101d])\\u1066",
						"\u1067");
		output_text = output_text.replaceAll("\\u1039\\u1007", "\u1068");
		output_text = output_text.replaceAll("\\u1039\\u1008", "\u1069");
		output_text = output_text.replaceAll("\\u1039\\u105b", "\u1068\u107d"); // nnnn
		output_text = output_text.replaceAll("\\u1039\\u100a", "\u109b");
		output_text = output_text.replaceAll("\\u1039\\u100d", "\u109c");
		output_text = output_text.replaceAll("\\u1039\\u100f", "\u1070");
		output_text = output_text.replaceAll("\\u1039\\u1010", "\u1071");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u1001\\u1002\\u1004\\u1005\\u1007\\u1012\\u1013\\u108f\\u1015\\u1016\\u1017\\u1019\\u101d])\\u1071",
						"\u1072");
		output_text = output_text.replaceAll("\\u1039\\u1011", "\u1073");
		output_text = output_text
				.replaceAll(
						"(?<=[\\u1001\\u1002\\u1004\\u1005\\u1007\\u1012\\u1013\\u108f\\u1015\\u1016\\u1017\\u1019\\u101d])\\u1073",
						"\u1074");
		output_text = output_text.replaceAll("\\u1039\\u1012", "\u1075");
		output_text = output_text.replaceAll("\\u1039\\u1013", "\u1076");
		output_text = output_text.replaceAll("\\u1039\\u1014", "\u1077");
		output_text = output_text.replaceAll("\\u1039\\u1015", "\u1078");
		output_text = output_text.replaceAll("\\u1039\\u1016", "\u1079");
		output_text = output_text.replaceAll("\\u1039\\u1017", "\u107a");
		output_text = output_text.replaceAll("\\u1039\\u1018", "\u107b");
		output_text = output_text.replaceAll("\\u1039\\u1019", "\u107c");
		output_text = output_text.replaceAll("\\u1039\\u101c", "\u1085");
		output_text = output_text.replaceAll("\\u1039\\u101e", "\u105d");
		output_text = output_text.replaceAll("\\u1039\\u1021", "\u105f");
		output_text = output_text.replaceAll("\\u100f\\u1039\\u100d", "\u1091");
		output_text = output_text.replaceAll("\\u100b\\u1039\\u100c", "\u1092");
		output_text = output_text.replaceAll("\\u1039\\u100c", "\u106d");
		output_text = output_text.replaceAll("\\u100b\\u1039\\u100b", "\u1097");
		output_text = output_text.replaceAll("\\u1039\\u100b", "\u106c");
		output_text = output_text.replaceAll("\\u100d\\u1039\\u100e", "\u106f");
		output_text = output_text.replaceAll("\\u100d\\u1039\\u100d", "\u106e");
		output_text = output_text.replaceAll("\\u1009(?=\\u103a)", "\u1025");
		output_text = output_text.replaceAll(
				"\\u1025(?=[\\u1039\\u102f\\u1030])", "\u106a");
		output_text = output_text.replaceAll("\\u1025", "\u1025");
		output_text = output_text.replaceAll("\\u103a", "\u1039");
		output_text = output_text.replaceAll("\\u103b\\u103d\\u103e",
				"\u107d\u108a"); // new
		output_text = output_text.replaceAll("\\u103d\\u103e", "\u108a");
		output_text = output_text.replaceAll("\\u103b", "\u103a");
		output_text = output_text.replaceAll("\\u103c", "\u103b");
		output_text = output_text.replaceAll("\\u103d", "\u103c");
		output_text = output_text.replaceAll("\\u103e", "\u103d");
		output_text = output_text.replaceAll("\\u105e", "\u103e"); // na
		output_text = output_text.replaceAll("\\u1039\\u105c", "\u105e"); // monbba
		output_text = output_text.replaceAll("\\u1039\\u1050", "\u105e"); // monbba
		output_text = output_text.replaceAll("\\u103e\\u102f", "\u1088");
		output_text = output_text.replaceAll("\\u103e\\u1030", "\u1089");
		output_text = output_text.replaceAll("\\u103d\\u1033", "\u1088"); // new
		output_text = output_text.replaceAll("\\u103d\\u1034", "\u1089"); // new
		output_text = output_text.replaceAll(
				"\\u103a(?=[\\u103c\\u103d\\u108a])", "\u107d");
		output_text = output_text
				.replaceAll(
						"(?<=\\u100a(?:[\\u102d\\u102e\\u1036\\u108b\\u108c\\u108d\\u108e\\u1098\\u109a]))\\u103d",
						"\u1087");
		output_text = output_text.replaceAll("(?<=\\u100a)\\u103d", "\u1087");
		output_text = output_text
				.replaceAll(
						"\\u103b(?=[\\u1000\\u1003\\u1006\\u100f\\u1010\\u1011\\u1018\\u101a\\u101c\\u101e\\u101f\\u1021])",
						"\u107e");
		output_text = output_text
				.replaceAll(
						"\\u107e([\\u1000-\\u1021\\u108f])(?=[\\u102d\\u102e\\u1032\\u1035\\u1036\\u109d\\u1098\\u1099\\u108b\\u108c\\u108d\\u108e\\u109a])",
						"\u1080$1");
		output_text = output_text.replaceAll(
				"\\u107e([\\u1000-\\u1021\\u108f])(?=[\\u103c\\u108a])",
				"\u1082$1");
		output_text = output_text
				.replaceAll(
						"\\u103b([\\u1000-\\u1021\\u108f])(?=[\\u102d\\u102e\\u1032\\u1035\\u1036\\u109d\\u1098\\u1099\\u108b\\u108c\\u108d\\u108e\\u109a])",
						"\u107f$1");
		output_text = output_text.replaceAll(
				"\\u103b([\\u1000-\\u1021\\u108f])(?=[\\u103c\\u108a])",
				"\u1081$1");
		output_text = output_text.replaceAll("(?<=\\u1014)\\u1037", "\u1094");
		output_text = output_text.replaceAll(
				"(?<=\\u1014[\\u103a\\u1032])\\u1037", "\u1094");
		output_text = output_text.replaceAll("(?<=\\u1033)\\u1094", "\u1095");
		output_text = output_text.replaceAll("(?<=\\u1033[\\u1036])\\u1094",
				"\u1095");
		output_text = output_text.replaceAll("(?<=\\u1034)\\u1094", "\u1095");
		output_text = output_text.replaceAll("(?<=\\u1034[\\u1036])\\u1094",
				"\u1095");
		output_text = output_text.replaceAll(
				"(?<=[\\u103c\\u103d\\u108a])\\u1037", "\u1095");
		output_text = output_text.replaceAll(
				"(?<=[\\u103c\\u103d\\u108a][\\u1032])\\u1037", "\u1095");
		output_text = output_text.replaceAll(
				"(\u101B)([\u109D\u1099\u102E\u102D]?)(\u102F)", "\u1090$2$3"); // s-Ra
		return output_text;
	}
}