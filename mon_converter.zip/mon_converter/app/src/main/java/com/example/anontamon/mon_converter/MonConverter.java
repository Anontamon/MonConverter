package com.example.anontamon.mon_converter;

import com.example.anontamon.mon_converter.CopyOneDisplayOutputActivity;
import com.example.anontamon.mon_converter.CopyTowDisplayOutputActivity;
import com.example.anontamon.mon_converter.DisplayOutputActivity;
import com.example.anontamon.mon_converter.R;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.ClipboardManager;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressWarnings({ "deprecation" })
public class MonConverter extends Activity {

	public final static String OUTPUT_TEXT = "com.example.mon_converter.MESSAGE";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_mon_converter);

		Button LoadButton = (Button) findViewById(R.id.LoadButton);
		LoadButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);

				ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				String TextIn = clipboard.getText().toString();

				TextArea.setText(TextIn);

			}
		});

		Button CopyButton = (Button) findViewById(R.id.CopyButton);
		CopyButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();
				ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				clipboard.setText(TextData);

				Context context = getApplicationContext();
				CharSequence text = "Text has loaded into clipboard";
				int duration = Toast.LENGTH_LONG;

				Toast toast = Toast.makeText(context, text, duration);
				toast.show();

			}
		});

		Button ClearButton = (Button) findViewById(R.id.ClearButton);
		ClearButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				TextArea.setText("");

			}
		});

		Button AboutButton = (Button) findViewById(R.id.aboutButton);
		AboutButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				Intent in1 = new Intent(MonConverter.this, About.class);
				startActivity(in1);
			}
		});

		Button M2UniButton = (Button) findViewById(R.id.M2UniButton);
		M2UniButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {

				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						DisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, MonToUni.mon2uni(TextData));
				startActivity(intent);
			}
		});

		Button Uni2MButton = (Button) findViewById(R.id.Uni2MButton);
		Uni2MButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						CopyOneDisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, UniToMon.uni2mon(TextData));
				startActivity(intent);

			}
		});

		Button Z2UniButton = (Button) findViewById(R.id.Z2UniButton);
		Z2UniButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						DisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, ZawToUni.zg2uni(TextData));
				startActivity(intent);

			}
		});

		Button Uni2ZButton = (Button) findViewById(R.id.Uni2ZButton);
		Uni2ZButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						CopyOneDisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, UniToZaw.uni2zg(TextData));
				startActivity(intent);

			}
		});

		Button U2UniButton = (Button) findViewById(R.id.U2UniButton);
		U2UniButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						DisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, UniMonToUni.um2uni(TextData));
				startActivity(intent);

			}
		});

		Button Uni2UButton = (Button) findViewById(R.id.Uni2UButton);
		Uni2UButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						CopyTowDisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, UniToUniMon.uni2umon(TextData));
				startActivity(intent);

			}
		});

		Button MMon2UniButton = (Button) findViewById(R.id.MMon2UniButton);
		MMon2UniButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						DisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, OneMonToUni.mmona(TextData));
				startActivity(intent);

			}
		});

		Button MMona2UniButton = (Button) findViewById(R.id.mMona2UniButton);
		MMona2UniButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						DisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, MMonToUni.mmonb(TextData));
				startActivity(intent);

			}
		});

		Button a12UButton = (Button) findViewById(R.id.a12UButton);
		a12UButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						DisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, A1ToUni.mmonc(TextData));
				startActivity(intent);

			}
		});

		Button Ant2UButton = (Button) findViewById(R.id.ant2UniButton);
		Ant2UButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				EditText TextArea = (EditText) findViewById(R.id.EditText1);
				String TextData = TextArea.getText().toString();

				Intent intent = new Intent(MonConverter.this,
						DisplayOutputActivity.class);
				intent.putExtra(OUTPUT_TEXT, AntToUni.ant2uni(TextData));
				startActivity(intent);

			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_mon_converter, menu);
		return true;
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
	}

}
