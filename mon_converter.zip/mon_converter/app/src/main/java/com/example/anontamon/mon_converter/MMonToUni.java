package com.example.anontamon.mon_converter;

public class MMonToUni {

	public static String mmonb(String input_text) {
		String output_text = input_text;
		output_text = output_text.replaceAll("\\u0075", "\u1000");
		output_text = output_text.replaceAll("\\u0063", "\u1001");
		output_text = output_text.replaceAll("\\u002A", "\u1002");
		output_text = output_text.replaceAll("\\u0043", "\u1003");
		output_text = output_text.replaceAll("\\u0069", "\u105A");
		output_text = output_text.replaceAll("\\u0070", "\u1005");
		output_text = output_text.replaceAll("\\u0071", "\u1006");
		output_text = output_text.replaceAll("\\u002E", "\u1007");
		// gha
		output_text = output_text.replaceAll("\\u00F3", "\u1009");
		// "\u00CD", "\u1009",
		output_text = output_text.replaceAll("\\u006E", "\u100A");
		// "\u00F1", "\u100A",
		output_text = output_text.replaceAll("\\u0025", "\u100B");
		output_text = output_text.replaceAll("\\u00C5", "\u100B");
		output_text = output_text.replaceAll("\\u0058", "\u100C");
		output_text = output_text.replaceAll("\\u0060", "\u100D");
		output_text = output_text.replaceAll("\\u00C4", "\u100D");
		output_text = output_text.replaceAll("\\u00F2", "\u100E");
		output_text = output_text.replaceAll("\\u0021", "\u100F");
		output_text = output_text.replaceAll("\\u0077", "\u1010");
		output_text = output_text.replaceAll("\\u0078", "\u1011");
		output_text = output_text.replaceAll("\\u003D", "\u1012");
		output_text = output_text.replaceAll("\\u005D", "\u1013");
		output_text = output_text.replaceAll("\\u0065", "\u1014");
		output_text = output_text.replaceAll("\\u0045", "\u1014");
		output_text = output_text.replaceAll("\\u0079", "\u1015");
		output_text = output_text.replaceAll("\\u007A", "\u1016");
		output_text = output_text.replaceAll("\\u0041", "\u1017");
		output_text = output_text.replaceAll("\\u0062", "\u1018");
		output_text = output_text.replaceAll("\\u0072", "\u1019");
		output_text = output_text.replaceAll("\\u002C", "\u101A");
		output_text = output_text.replaceAll("\\u0037", "\u101B");
		output_text = output_text.replaceAll("\\u0026", "\u101B");
		output_text = output_text.replaceAll("\\u0076", "\u101C");
		output_text = output_text.replaceAll("\\u0030", "\u101D");
		output_text = output_text.replaceAll("\\u006F", "\u101E");
		output_text = output_text.replaceAll("\\u00CC", "\u103F");
		output_text = output_text.replaceAll("\\u005B", "\u101F");
		output_text = output_text.replaceAll("\\u0056", "\u1020");
		output_text = output_text.replaceAll("\\u005C", "\u105C");
		output_text = output_text.replaceAll("\\u0074", "\u1021");
		output_text = output_text.replaceAll("\\u00F4", "\u105D");
		output_text = output_text.replaceAll("\\u006D", "\u102C");
		output_text = output_text.replaceAll("\\u0067", "\u102B");
		output_text = output_text.replaceAll("\\u0064", "\u102D");
		output_text = output_text.replaceAll("\\u0046", "\u1033");
		output_text = output_text.replaceAll("\\u0044", "\u102E");
		output_text = output_text.replaceAll("\\u006B", "\u102F");
		output_text = output_text.replaceAll("\\u004B", "\u102F");
		output_text = output_text.replaceAll("\\u006C", "\u1030");
		output_text = output_text.replaceAll("\\u004C", "\u1030");
		output_text = output_text.replaceAll("\\u0061", "\u1031");
		output_text = output_text.replaceAll("\\u004A", "\u1032");
		output_text = output_text.replaceAll("\\u006A", "\u1034");
		output_text = output_text.replaceAll("\\u0054", "\u1035");
		output_text = output_text.replaceAll("\\u0048", "\u1036");
		output_text = output_text.replaceAll("\\u003B", "\u1038");
		output_text = output_text.replaceAll("\\u0066", "\u103A");
		output_text = output_text.replaceAll("\\u0073", "\u103B");
		// "\u00DF", "\u103B",
		output_text = output_text.replaceAll("\\u002D", "\u103C");
		output_text = output_text.replaceAll("\\u00AD", "\u103C");
		output_text = output_text.replaceAll("\\u0068", "\u103C");
		output_text = output_text.replaceAll("\\u2020", "\u103C\u102F");
		// "\u0060", "\u103C",
		// "\u00DD", "\u103C",
		// "\u00DE", "\u103C",
		output_text = output_text.replaceAll("\\u0047", "\u103D");
		output_text = output_text.replaceAll("\\u0053", "\u103E");
		// "\u00A7", "\u103E",
		output_text = output_text.replaceAll("\\u0031", "\u1041");
		output_text = output_text.replaceAll("\\u0032", "\u1042");
		output_text = output_text.replaceAll("\\u0033", "\u1043");
		output_text = output_text.replaceAll("\\u0034", "\u1044");
		output_text = output_text.replaceAll("\\u0035", "\u1045");
		output_text = output_text.replaceAll("\\u0036", "\u1046");
		output_text = output_text.replaceAll("\\u005E", "\u1047");
		output_text = output_text.replaceAll("\\u0038", "\u1048");
		output_text = output_text.replaceAll("\\u0039", "\u1049");
		output_text = output_text.replaceAll("\\u002F", "\u104A");
		output_text = output_text.replaceAll("\\u003F", "\u104B");
		output_text = output_text.replaceAll("\\u00F5", "\u104E");
		output_text = output_text.replaceAll("\\u00C2", "\u104E");
		output_text = output_text.replaceAll("\\u0027", "\u105E");
		output_text = output_text.replaceAll("\\u0022", "\u105F");
		output_text = output_text.replaceAll("\\u004D", "\u1060");
		output_text = output_text.replaceAll("\\u02C6", "\u003F");
		output_text = output_text.replaceAll("\\u005F", "\u002E");
		output_text = output_text.replaceAll("\\u00DC", "\u1023");
		output_text = output_text.replaceAll("\\u004F", "\u1025");
		output_text = output_text.replaceAll("\\u007B", "\u1028");
		output_text = output_text.replaceAll("\\u0055", "\u1000\u1039\u1000");
		output_text = output_text.replaceAll("\\u0152", "\u101E\u1039\u1000");
		output_text = output_text.replaceAll("\\u0051", "\u1000\u1039\u1001");
		output_text = output_text.replaceAll("\\u0049", "\u1039\u1002");
		output_text = output_text.replaceAll("\\u00AA", "\u1002\u1039\u1002");
		output_text = output_text.replaceAll("\\u00C9", "\u1002\u1039\u1003");
		output_text = output_text.replaceAll("\\u005A", "\u1039\u105A");
		output_text = output_text.replaceAll("\\u0050", "\u1039\u1005");
		output_text = output_text.replaceAll("\\u00B1", "\u1005\u1039\u1005");
		output_text = output_text.replaceAll("\\u00B6", "\u1009\u1039\u1005");
		output_text = output_text.replaceAll("\\u00A6", "\u1005\u1039\u1006");
		output_text = output_text.replaceAll("\\u00D5", "\u1009\u1039\u1006");
		output_text = output_text.replaceAll("\\u003E", "\u1039\u1007");
		output_text = output_text.replaceAll("\\u00A4", "\u1007\u1039\u1007");
		output_text = output_text.replaceAll("\\u00C3", "\u1009\u1039\u1007");
		output_text = output_text.replaceAll("\\u00EA", "\u1007\u1039\u105B");
		output_text = output_text.replaceAll("\\u00BF", "\u1009\u1039\u105B");
		output_text = output_text.replaceAll("\\u00D8", "\u1007\u1039\u1008");
		output_text = output_text.replaceAll("\\u00DB", "\u1009\u1039\u1008");
		output_text = output_text.replaceAll("\\u0161", "\u1010\u1039\u100A");
		output_text = output_text.replaceAll("\\u203A", "\u1000\u1039\u100A");
		output_text = output_text.replaceAll("\\u0153", "\u1002\u1039\u100A");
		output_text = output_text.replaceAll("\\u0178", "\u1017\u1039\u100A");
		output_text = output_text.replaceAll("\\u00D4", "\u100F\u1039\u100B");
		output_text = output_text.replaceAll("\\u00A1", "\u100F\u1039\u100C");
		output_text = output_text.replaceAll("\\u007E", "\u1039\u100D");
		// "\u2219", "\u1039\u100E",
		// "\u00B7", "\u1039\u100E",
		output_text = output_text.replaceAll("\\u0023", "\u100F\u1039\u100F");
		output_text = output_text.replaceAll("\\u0057", "\u1039\u1010");
		output_text = output_text.replaceAll("\\u00AC", "\u1014\u1039\u1010");
		output_text = output_text.replaceAll("\\u00AE", "\u1017\u1039\u1010");
		output_text = output_text.replaceAll("\\u00AF", "\u1019\u1039\u1010");
		output_text = output_text.replaceAll("\\u00B7", "\u1010\u1039\u1010");
		output_text = output_text.replaceAll("\\u00A9", "\u1000\u1039\u1011");
		output_text = output_text.replaceAll("\\u00B0",
				"\u1010\u1039\u1011\u103D");
		output_text = output_text.replaceAll("\\u00BE", "\u1010\u1039\u1011");
		output_text = output_text.replaceAll("\\u00CD", "\u1014\u1039\u1011");
		output_text = output_text.replaceAll("\\u002B", "\u1039\u1012");
		output_text = output_text.replaceAll("\\u00B9", "\u1012\u1039\u1012");
		output_text = output_text.replaceAll("\\u004E", "\u1014\u1039\u1012");
		output_text = output_text.replaceAll("\\u003C", "\u1012\u1039\u1013");
		output_text = output_text.replaceAll("\\u00DD", "\u1014\u1039\u1013");
		output_text = output_text.replaceAll("\\u00D9", "\u1014\u1039\u1014");
		output_text = output_text.replaceAll("\\u0059", "\u1039\u1015");
		output_text = output_text.replaceAll("\\u0024", "\u1019\u1039\u1015");
		output_text = output_text.replaceAll("\\u00C6", "\u1019\u1039\u1016");
		output_text = output_text.replaceAll("\\u00CB", "\u1019\u1039\u1016");
		output_text = output_text.replaceAll("\\u00C7", "\u1015\u1039\u1016");
		output_text = output_text.replaceAll("\\u00C8", "\u1017\u1039\u1017");
		output_text = output_text.replaceAll("\\u00D2", "\u1019\u1039\u1017");
		output_text = output_text.replaceAll("\\u00CE", "\u1017\u1039\u1018");
		output_text = output_text.replaceAll("\\u0042", "\u1019\u1039\u1018");
		output_text = output_text.replaceAll("\\u00CF", "\u101E\u1039\u1018");
		output_text = output_text.replaceAll("\\u0052", "\u1039\u1019");
		output_text = output_text.replaceAll("\\u00B3", "\u1019\u1039\u1019");
		output_text = output_text.replaceAll("\\u00CA", "\u101F\u1039\u1019");
		output_text = output_text.replaceAll("\\u00D6", "\u101E\u1039\u1019");
		output_text = output_text.replaceAll("\\u00C0", "\u1000\u1039\u101C");
		output_text = output_text.replaceAll("\\u00C1", "\u101C\u1039\u101C");
		// "\u00CA", "\u1039\u101E",
		output_text = output_text.replaceAll("\\u007C", "\u1039\u105C");
		output_text = output_text.replaceAll("\\u2018", "\u101C\u1039\u1021");
		output_text = output_text.replaceAll("\\u2019", "\u1016\u1039\u1021");

		output_text = output_text.replaceAll("\\u00E1", "\u105A\u103A\u1039");
		// "\u0024", "\u102D\u1032",
		output_text = output_text.replaceAll("\\u003A", "\u102B\u103A");
		output_text = output_text.replaceAll("\\u00F6", "\u103B\u103E");
		output_text = output_text.replaceAll("\\u00EE", "\u103D\u103E");
		// "\u00A1", "\u103C\u102F",
		// "\u00AF", "\u103C\u102F",
		// "\u00EA", "\u103C\u102F",
		// "\u00FB", "\u103C\u102F",
		// "\u00AA", "\u102B\u1032",
		// "\u00F9", "\u102B\u1036",
		// "\u00FC","\u105A\u103A\u1039\u102B",
		output_text = output_text.replaceAll("\\u00E3",
				"\u105A\u103A\u1039\u102D");
		output_text = output_text.replaceAll("\\u00E9",
				"\u105A\u103A\u1039\u1033");
		output_text = output_text.replaceAll("\\u00E4",
				"\u105A\u103A\u1039\u1036");
		output_text = output_text.replaceAll("\\u00E0",
				"\u105A\u103A\u1039\u102E");
		output_text = output_text.replaceAll("\\u00E2", "\u102D\u1036");

		// "\u00D3", "\u1009\u102C",
		output_text = output_text.replaceAll("\\u0040", "\u100F\u1039\u100D");
		output_text = output_text.replaceAll("\\u007D", "\u100B\u1039\u100C");
		output_text = output_text.replaceAll("\\u00BB", "\u100B\u1039\u100B");
		output_text = output_text.replaceAll("\\u00BC", "\u100D\u1039\u100D");
		output_text = output_text.replaceAll("\\u00DA", "\u100D\u1039\u100E");
		// "\u00DB", "\u1020\u103E",
		output_text = output_text.replaceAll("\\u00D3",
				"\u1014\u1039\u1010\u103D");
		output_text = output_text.replaceAll("\\u00EC", "\u103E\u102F");
		output_text = output_text.replaceAll("\\u00E5", "\u103E\u1030");
		output_text = output_text.replaceAll("\\u00AB", "\u104D");
		output_text = output_text.replaceAll("\\u00B4", "\u1024");
		output_text = output_text.replaceAll("\\u00B8", "\u104C");
		output_text = output_text.replaceAll("\\u00E7", "\u104F");
		output_text = output_text.replaceAll("\\u2021", "\u1037");
		output_text = output_text.replaceAll("\\u00E8", "\u1037");
		output_text = output_text.replaceAll("\\u00E6", "\\u0022");
		output_text = output_text.replaceAll("\\u00BE", "\u0027");
		output_text = output_text.replaceAll("\\u00BD", "\u0027");
		output_text = output_text.replaceAll("\\u201E", "\u002D");
		output_text = output_text.replaceAll("\\u2013", "\u005F");
		output_text = output_text.replaceAll("\\u00D0", "\u02DF");
		output_text = output_text.replaceAll("\\u00D7", "\u007B");
		output_text = output_text.replaceAll("\\u00FD", "\u007B");
		output_text = output_text.replaceAll("\\u00FE", "\u007D");
		output_text = output_text.replaceAll("\\u00DE", "\u007E");
		output_text = output_text.replaceAll("\\u00EF", "\u00F7");
		output_text = output_text.replaceAll("\\u00F0", "\u002B");
		output_text = output_text.replaceAll("\\u00F7", "\u003D");
		output_text = output_text.replaceAll("\\u00F1", "\u002F");
		output_text = output_text.replaceAll("\\u00F8", "\u005B");
		output_text = output_text.replaceAll("\\u00BA", "\u103B\u103D");
		output_text = output_text.replaceAll("\\u00FA", "\u005D");
		output_text = output_text
				.replaceAll("(\\u105A\\u1037)", "\u1004\u1037"); // Mon&Bure
		output_text = output_text
				.replaceAll("(\\u105A\\u103B)", "\u1004\u103B"); // Mon&Bure
		output_text = output_text.replaceAll("(\\u103C\u105A)", "\u1004\u103C"); // Mon&Bure
		output_text = output_text
				.replaceAll("(\\u105A\\u103D)", "\u1004\u103D"); // Mon&Bure
		output_text = output_text
				.replaceAll("(\\u105A\\u103E)", "\u1004\u103E"); // Mon&Bure
		output_text = output_text.replaceAll(
				"\\u105A([\\u102B\\u102C]?)(\\u1037)", "\u1004\u102B\u1037"); // Mon&Bure
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])(\\u102C)\\u00E1",
						"\u105A\u103A\u1039$1$2$3$4"); // kinizi i
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])\\u00E4",
				"\u105A\u103A\u1039$1$2$3\u1036"); // Kinzi ai
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])\\u00E8",
				"\u105A\u103A\u1039$1$2$3\u1033"); // kinzi Mon ii
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])\\u00E0",
				"\u105A\u103A\u1039$1$2$3\u102E");
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])\\u00E3   ",
				"\u105A\u103A\u1039$1$2$3\u102D");

		// reoder
		output_text = output_text.replaceAll("(\\u103A)(\\u1037)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u102D)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1035)", "$2$1");
		//
		// Ra&HawayMu
		output_text = output_text.replaceAll(
				"(\\u103C)([\\u1000-\\u1021])((?:\\u1039[\\u1000-\\u1021])?)",
				"$2$3$1");
		output_text = output_text.replaceAll(
				"(\\u103C)(\\u103D)([\\u1000-\\u1021])", "$3$1$2");
		// reordering ra

		// output_text = output_text.replaceAll(
		// "(\u103E)?(\u103D)?([\u103B\u103C])   ", "$3$2$1");
		// reordering ra

		output_text = output_text.replaceAll(
				"(\\u103E)(\\u103D)([\\u103B\\u103C])   ", "$3$2$1");
		output_text = output_text.replaceAll("(\\u103E)([\\u103B\\u103C])   ",
				"$2$1");

		output_text = output_text.replaceAll("(\\u103D)([\\u103B\\u103C])   ",
				"$2$1");
		// Ra&HawayMu
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)([\\u1000-\\u1021])((?:\\u1039[\\u1000-\\u1021\\u105A\\u105C])?)((?:[\\u102D\\u102E\\u1032\\u1033\\u1034\\u1035])?)([\\u1036\\u1037\\u1038]{0,2})([\\u103B-\\u103C]{0,3})((?:[\\u102F\\u1030])?)([\\u1036\\u1037\\u1038]{0,2})((?:[\\u102D\\u102E\\u1032])?)",
						"$2$3$6$1$4$9$7$5$8");

		output_text = output_text.replaceAll("(\\u103A)(\\u1037)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1035)", "$2$1");
		output_text = output_text.replaceAll("(\\u1032)(\\u102F)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1033)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u102D)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u102E)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1033)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1035)", "$2$1");
		output_text = output_text.replaceAll("(\\u1032)(\\u103D)", "$2$1");
		output_text = output_text.replaceAll("(\\u103A)(\\u103E)", "$2$1");
		output_text = output_text
				.replaceAll(
						"([\\u102D\\u102E\\u1032-\\u1036])([\\u105E\\u105F\\u1060\\u103D\\u103E])",
						"$2$1");
		output_text = output_text
				.replaceAll(
						"([\\u102D\\u102E\\u1032-\\u1035])((?:\\u1039[\\u1000-\\u1021\\u105A\\u105C])?)",
						"$2$1");
		output_text = output_text.replaceAll(
				"\\u1031([\\u103A\\u103B-\\u103E\\u105C-\\u105F\\u1060]+)",
				"$1\u1031");
		output_text = output_text.replaceAll(
				"\\u1031((?:\\u1039[\\u1000-\\u1021\\u105A\\u105C])?)",
				"$1\u1031");
		output_text = output_text.replaceAll("\\u1031([\\u105B\\u105D])",
				"$1\u1031");
		output_text = output_text.replaceAll("\\u1032\\u102F", "$2$1");
		return output_text;
	}
}
