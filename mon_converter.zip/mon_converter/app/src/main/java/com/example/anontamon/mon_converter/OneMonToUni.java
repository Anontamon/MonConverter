package com.example.anontamon.mon_converter;

public class OneMonToUni {

	public static String mmona(String input_text) {
		String output_text = input_text;
		output_text = output_text.replaceAll("\\u0075", "\u1000");
		output_text = output_text.replaceAll("\\u0063", "\u1001");
		output_text = output_text.replaceAll("\\u002A", "\u1002");
		output_text = output_text.replaceAll("\\u0043", "\u1003");
		output_text = output_text.replaceAll("\\u0069", "\u105A");
		output_text = output_text.replaceAll("\\u0070", "\u1005");
		output_text = output_text.replaceAll("\\u0071", "\u1006");
		output_text = output_text.replaceAll("\\u002E", "\u1007");
		// jha
		output_text = output_text.replaceAll("\\u00F3", "\u1009");

		output_text = output_text.replaceAll("\\u006E", "\u100A");
		output_text = output_text.replaceAll("\\u0025", "\u100B");
		output_text = output_text.replaceAll("\\u00BD", "\u100B");
		output_text = output_text.replaceAll("\\u00A4", "\u100C");
		output_text = output_text.replaceAll("\\u0060", "\u100D");
		output_text = output_text.replaceAll("\\u00F2", "\u100E");
		output_text = output_text.replaceAll("\\u0021", "\u100F");
		output_text = output_text.replaceAll("\\u0077", "\u1010");
		output_text = output_text.replaceAll("\\u0078", "\u1011");
		output_text = output_text.replaceAll("\\u003D", "\u1012");
		output_text = output_text.replaceAll("\\u005D", "\u1013");
		output_text = output_text.replaceAll("\\u0065", "\u1014");
		output_text = output_text.replaceAll("\\u0045", "\u1014");
		output_text = output_text.replaceAll("\\u0079", "\u1015");
		output_text = output_text.replaceAll("\\u007A", "\u1016");
		output_text = output_text.replaceAll("\\u0041", "\u1017");
		output_text = output_text.replaceAll("\\u0062", "\u1018");
		output_text = output_text.replaceAll("\\u0072", "\u1019");
		output_text = output_text.replaceAll("\\u002C", "\u101A");
		output_text = output_text.replaceAll("\\u0037", "\u101B");
		output_text = output_text.replaceAll("\\u0026", "\u101B");
		output_text = output_text.replaceAll("\\u0076", "\u101C");
		output_text = output_text.replaceAll("\\u0030", "\u101D");
		output_text = output_text.replaceAll("\\u006F", "\u101E");
		output_text = output_text.replaceAll("\\u00CC", "\u103F");
		output_text = output_text.replaceAll("\\u005B", "\u101F");
		output_text = output_text.replaceAll("\\u0056", "\u1020");
		output_text = output_text.replaceAll("\\u0074", "\u1021");
		output_text = output_text.replaceAll("\\u00F4", "\u105D");
		output_text = output_text.replaceAll("\\u006D", "\u102C");
		output_text = output_text.replaceAll("\\u0067", "\u102B");
		output_text = output_text.replaceAll("\\u0064", "\u102D");
		output_text = output_text.replaceAll("\\u0046", "\u1033");
		output_text = output_text.replaceAll("\\u0044", "\u102E");
		output_text = output_text.replaceAll("\\u006B", "\u102F");
		output_text = output_text.replaceAll("\\u004B", "\u102F");
		output_text = output_text.replaceAll("\\u006C", "\u1030");
		output_text = output_text.replaceAll("\\u004C", "\u1030");
		output_text = output_text.replaceAll("\\u0061", "\u1031");
		output_text = output_text.replaceAll("\\u004A", "\u1032");
		output_text = output_text.replaceAll("\\u006A", "\u1034");
		output_text = output_text.replaceAll("\\u0054", "\u1035");
		output_text = output_text.replaceAll("\\u0048", "\u1036");
		output_text = output_text.replaceAll("\\u003B", "\u1038");
		output_text = output_text.replaceAll("\\u0066", "\u103A");
		output_text = output_text.replaceAll("\\u0073", "\u103B");

		output_text = output_text.replaceAll("\\u0068", "\u103C");
		output_text = output_text.replaceAll("\\u0042", "\u103C");
		output_text = output_text.replaceAll("\\u00AA", "\u103C");
		output_text = output_text.replaceAll("\\u00A9", "\u103C");

		output_text = output_text.replaceAll("\\u0047", "\u103D");
		output_text = output_text.replaceAll("\\u0053", "\u103E");
		output_text = output_text.replaceAll("\\u00B5", "\u103E");
		output_text = output_text.replaceAll("\\u0031", "\u1041");
		output_text = output_text.replaceAll("\\u0032", "\u1042");
		output_text = output_text.replaceAll("\\u0033", "\u1043");
		output_text = output_text.replaceAll("\\u0034", "\u1044");
		output_text = output_text.replaceAll("\\u0035", "\u1045");
		output_text = output_text.replaceAll("\\u0036", "\u1046");
		output_text = output_text.replaceAll("\\u0037", "\u1047");
		output_text = output_text.replaceAll("\\u0038", "\u1048");
		output_text = output_text.replaceAll("\\u0039", "\u1049");
		output_text = output_text.replaceAll("\\u002F", "\u104A");
		output_text = output_text.replaceAll("\\u003F", "\u104B");

		output_text = output_text.replaceAll("\\u0027", "\u105E");
		output_text = output_text.replaceAll("\\u0022", "\u105F");
		output_text = output_text.replaceAll("\\u004D", "\u1060");
		output_text = output_text.replaceAll("\\u00A3", "\u003F");
		output_text = output_text.replaceAll("\\u00E8", "\u002E");
		output_text = output_text.replaceAll("\\u00E5", "\u002E");
		output_text = output_text.replaceAll("\\u00B9", "\u2026");
		output_text = output_text.replaceAll("\\u00DC", "\u1023");
		output_text = output_text.replaceAll("\\u004F", "\u1025");
		output_text = output_text.replaceAll("\\u007B", "\u1028");
		output_text = output_text.replaceAll("\\u0055", "\u1039\u1000");
		output_text = output_text.replaceAll("\\u0051", "\u1039\u1001");
		output_text = output_text.replaceAll("\\u0049", "\u1039\u1002");
		output_text = output_text.replaceAll("\\u005A", "\u1039\u105A");
		output_text = output_text.replaceAll("\\u0050", "\u1039\u1005");
		output_text = output_text.replaceAll("\\u00B1", "\u1039\u1006");
		output_text = output_text.replaceAll("\\u003E", "\u1039\u1007");
		output_text = output_text.replaceAll("\\u00AB", "\u1039\u100A");
		output_text = output_text.replaceAll("\\u00B7", "\u1039\u100A");

		output_text = output_text.replaceAll("\\u007E", "\u1039\u100D");

		output_text = output_text.replaceAll("\\u0057", "\u1039\u1010");

		output_text = output_text.replaceAll("\\u0058", "\u1039\u1011");
		output_text = output_text.replaceAll("\\u002B", "\u1039\u1012");
		output_text = output_text.replaceAll("\\u003C", "\u1039\u1013");
		output_text = output_text.replaceAll("\\u004E", "\u1039\u1014");
		output_text = output_text.replaceAll("\\u0059", "\u1039\u1015");
		output_text = output_text.replaceAll("\\u00C7", "\u1039\u1016");
		output_text = output_text.replaceAll("\\u00C8", "\u1039\u1017");
		output_text = output_text.replaceAll("\\u005E", "\u1039\u1018");

		output_text = output_text.replaceAll("\\u0052", "\u1039\u1019");
		output_text = output_text.replaceAll("\\u00C0", "\u1039\u101C");

		output_text = output_text.replaceAll("\\u007C", "\u1039\u105C");
		output_text = output_text.replaceAll("\u005F", "\u1039\u1021");

		output_text = output_text.replaceAll("\\u00E1", "\u105A\u103A\u1039");
		output_text = output_text.replaceAll("\\u0024", "\u102D\u1032");
		output_text = output_text.replaceAll("\\u003A", "\u102B\u103A");

		output_text = output_text.replaceAll("\\u00E3",
				"\u105A\u103A\u1039\u102D");
		output_text = output_text.replaceAll("\\u00E9",
				"\u105A\u103A\u1039\u1033");
		output_text = output_text.replaceAll("\\u00E0",
				"\u105A\u103A\u1039\u102E");
		output_text = output_text.replaceAll("\\u00E4",
				"\u105A\u103A\u1039\u1036");
		output_text = output_text.replaceAll("\\u00E2", "\u102D\u1036");

		output_text = output_text.replaceAll("\\u0040", "\u100F\u1039\u100D");
		output_text = output_text.replaceAll("\\u007D", "\u100B\u1039\u100C");
		output_text = output_text.replaceAll("\\u00BB", "\u100B\u1039\u100B");
		output_text = output_text.replaceAll("\\u00BC", "\u100D\u1039\u100D");
		output_text = output_text.replaceAll("\\u00DA", "\u100D\u1039\u100E");
		output_text = output_text.replaceAll("\\u00D3",
				"\u1014\u1039\u1010\u103D");
		output_text = output_text.replaceAll("\\u0023", "\u100F\u1039\u100F");
		output_text = output_text.replaceAll("\\u00A1", "\u100F\u1039\u100C");
		output_text = output_text.replaceAll("\\u00B0",
				"\u1010\u1039\1011\u103D");
		output_text = output_text.replaceAll("\\u00B8",
				"\u1014\u1039\u1012\u103C");
		output_text = output_text.replaceAll("\\u00C9", "\u1002\u1039\u1003");
		output_text = output_text.replaceAll("\\u00D4", "\u100F\u1039\u100B");
		output_text = output_text.replaceAll("\\u00D5", "\u1009\u1039\1006");
		output_text = output_text.replaceAll("\\u00DF", "\u1037");
		output_text = output_text.replaceAll("\\u00EB", "\u0027");
		output_text = output_text.replaceAll("\\u00ED", "\u0027");
		output_text = output_text.replaceAll("\\u00FB", "\\u0022");
		output_text = output_text.replaceAll("\\u00E6", "\\u0022");
		output_text = output_text.replaceAll("\\u00D0", "\u00D7");
		output_text = output_text.replaceAll("\\u00EF", "\u00F7");
		output_text = output_text.replaceAll("\\u00F0", "\u002B");
		output_text = output_text.replaceAll("\\u00F1", "\u002F");
		output_text = output_text.replaceAll("\\u00F7", "\u003D");
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])\\u0046",
				"\u0046$1$2$3");
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])\\u0046",
				"\u105A\u103A\u1039$1$2$3");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])\\u105A\\u103A\\u1039",
						"\u105A\u103A\u1039$1$2$3");
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])\\u0046",
				"\u105A\u103A\u1039$1$2$3"); // kinizi i
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])\\u00E4",
				"\u105A\u103A\u1039$1$2$3\u1036"); // Kinzi ai
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])\\u00E9",
				"\u105A\u103A\u1039$1$2$3\u1033"); // kinzi Mon ii
		output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])\\u00E0",
				"\u105A\u103A\u1039$1$2$3\u102E");
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])\\u00D8   ",
				"\u105A\u103A\u1039$1$2$3\u102D");

		// reoder
		output_text = output_text.replaceAll("(\\u103A)(\\u1037)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u102D)   ", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1035)   ", "$2$1");
		//
		// Ra&HawayMu
		output_text = output_text.replaceAll(
				"(\\u103C)([\\u1000-\\u1021])((?:\\u1039[\\u1000-\\u1021])?)",
				"$2$3$1");
		output_text = output_text.replaceAll(
				"(\\u103C)(\\u103D)([\\u1000-\\u1021])", "$3$1$2");
		// reordering ra

		// output_text = output_text.replaceAll(
		// "(\u103E)?(\u103D)?([\u103B\u103C])   ", "$3$2$1");
		// reordering ra

		output_text = output_text.replaceAll(
				"(\\u103E)(\\u103D)([\\u103B\\u103C])   ", "$3$2$1");
		output_text = output_text.replaceAll("(\\u103E)([\\u103B\\u103C])   ",
				"$2$1");

		output_text = output_text.replaceAll("(\\u103D)([\\u103B\\u103C])   ",
				"$2$1");
		// Ra&HawayMu
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)([\\u1000-\\u1021])((?:\\u1039[\\u1000-\\u1021\\u105A\\u105C])?)((?:[\\u102D\\u102E\\u1032\\u1033\\u1034\\u1035])?)([\\u1036\\u1038]{0,2})([\\u103B-\\u103C]{0,3})((?:[\\u102F\\u1030])?)([\\u1036\\u1038]{0,2})((?:[\\u102D\\u102E\\u1032])?)",
						"$2$3$6$1$4$9$7$5$8");

		output_text = output_text.replaceAll("(\\u102F)(\\u1035)", "$2$1");

		output_text = output_text.replaceAll("(\\u1032)(\\u102F)", "$2$1");

		output_text = output_text.replaceAll("(\\u1036)(\\u102F)", "$2$1");

		output_text = output_text.replaceAll("(\\u102F)(\\u1033)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u102D)", "$2$1");

		output_text = output_text.replaceAll("(\\u102F)(\\u102E)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1033)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1035)", "$2$1");
		output_text = output_text.replaceAll("(\\u1032)(\\u103D)", "$2$1");
		output_text = output_text.replaceAll("(\\u103A)(\\u103E)", "$2$1");
		output_text = output_text
				.replaceAll(
						"([\\u102D\\u102E\\u1032-\\u1036])([\\u105E\\u105F\\u1060\\u103D\\u103E])",
						"$2$1");
		output_text = output_text
				.replaceAll(
						"([\\u102D\\u102E\\u1032-\\u1035])((?:\\u1039[\\u1000-\\u1021\\u105A\\u105C])?)",
						"$2$1");
		output_text = output_text.replaceAll(
				"\\u1031([\\u103A\\u103B-\\u103E\\u105C-\\u105F\\u1060]+)",
				"$1\u1031");
		output_text = output_text.replaceAll(
				"\\u1031((?:\\u1039[\\u1000-\\u1021\\u105A\\u105C])?)",
				"$1\u1031");
		output_text = output_text.replaceAll("\\u1031([\\u105B\\u105D])",
				"$1\u1031");
		output_text = output_text.replaceAll("\\u1032\\u102F", "$2$1");
		output_text = output_text.replaceAll("\\u1025(?=[\\u1039\\u102C])",
				"\u1009");
		return output_text;
	}
}
