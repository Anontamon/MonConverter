package com.example.anontamon.mon_converter;

public class A1ToUni {

	public static String mmonc(String input_text) {
		String output_text = input_text;
		output_text = output_text.replaceAll("\\u0160", "\u1039\u1021");
		output_text = output_text.replaceAll("\\u00BC", "\u100F\u1030\u100C");
		output_text = output_text.replaceAll("\\u00B9", "\u1039\u1018");
		output_text = output_text.replaceAll("\\u00B2", "\u103C\u102F");
		output_text = output_text.replaceAll("\\u2212", "\u104C");
		output_text = output_text.replaceAll("\\u0021", "\u100B");
		output_text = output_text.replaceAll("\\u0022", "\u1039\u105C");
		output_text = output_text.replaceAll("\\u0023", "\u1039\u1005");
		output_text = output_text.replaceAll("\\u0024", "\u1039\u1006");
		output_text = output_text.replaceAll("\\u0025", "\u100F");
		output_text = output_text.replaceAll("\\u0026", "\u102D\u1032");
		output_text = output_text.replaceAll("\\u0027", "\u1039\u105C");
		output_text = output_text.replaceAll("\\u002A", "\u1039\u1000");
		output_text = output_text.replaceAll("\\u002B", "\u1039\u1011");
		output_text = output_text.replaceAll("\\u002C", "\u1038");
		output_text = output_text.replaceAll("\\u002E", "\u102C");
		output_text = output_text.replaceAll("\\u002F", "\u100D");
		output_text = output_text.replaceAll("\\u0030", "\u1039\u1012");
		output_text = output_text.replaceAll("\\u0031", "\u1041");
		output_text = output_text.replaceAll("\\u0032", "\u1042");
		output_text = output_text.replaceAll("\\u0033", "\u1043");
		output_text = output_text.replaceAll("\\u0034", "\u1044");
		output_text = output_text.replaceAll("\\u0035", "\u1045");
		output_text = output_text.replaceAll("\\u0036", "\u1046");
		output_text = output_text.replaceAll("\\u0037", "\u1047");
		output_text = output_text.replaceAll("\\u0038", "\u1048");
		output_text = output_text.replaceAll("\\u0039", "\u1049");
		output_text = output_text.replaceAll("\\u003A", "\u1039\u1001");
		output_text = output_text.replaceAll("\\u003B", "\u103B");
		output_text = output_text.replaceAll("\\u003C", "\u1039\u1002");
		output_text = output_text.replaceAll("\\u003D", "\u1039\u1010");
		output_text = output_text.replaceAll("\\u003E", "\u102B");
		output_text = output_text.replaceAll("\\u003F", "\u1039\u100D");
		output_text = output_text.replaceAll("\\u0040", "\u100B\u1039\u100C");
		output_text = output_text.replaceAll("\\u0041", "\u1025");
		output_text = output_text.replaceAll("\\u0043", "\u1039\u105A");
		output_text = output_text.replaceAll("\\u0044", "\u1013");
		output_text = output_text.replaceAll("\\u0045", "\u1035");
		output_text = output_text.replaceAll("\\u0046", "\u1014");
		output_text = output_text.replaceAll("\\u0047", "\u1003");
		output_text = output_text.replaceAll("\\u0048", "\u103E");
		output_text = output_text.replaceAll("\\u0049", "\u1033");
		output_text = output_text.replaceAll("\\u004A", "\u102E");
		output_text = output_text.replaceAll("\\u004B", "\u1001");
		output_text = output_text.replaceAll("\\u004C", "\u1060");
		output_text = output_text.replaceAll("\\u004D", "\u105F");
		output_text = output_text.replaceAll("\\u004E", "\u105E");
		output_text = output_text.replaceAll("\\u004F", "\u1034");
		output_text = output_text.replaceAll("\\u0050", "\u1039\u1015");
		output_text = output_text.replaceAll("\\u0051", "\u103F");
		output_text = output_text.replaceAll("\\u0052", "\u101B");
		output_text = output_text.replaceAll("\\u0053", "\u1006");
		output_text = output_text.replaceAll("\\u0054", "\u1011");
		output_text = output_text.replaceAll("\\u0055", "\u1030");
		output_text = output_text.replaceAll("\\u0057", "\u103D");
		output_text = output_text.replaceAll("\\u0058", "\u1039\u100A");
		output_text = output_text.replaceAll("\\u0059", "\u1032");
		output_text = output_text.replaceAll("\\u005A", "\u1039\u1007");
		output_text = output_text.replaceAll("\\u005B", "\u103C");
		output_text = output_text.replaceAll("\\u005C", "\u104A");
		output_text = output_text.replaceAll("\\u005D", "\u102F");
		output_text = output_text.replaceAll("\\u005E", "\u105D");
		output_text = output_text.replaceAll("\\u005F", "\u103C");
		output_text = output_text.replaceAll("\\u0060", "\u1020");
		output_text = output_text.replaceAll("\\u0061", "\u1021");
		output_text = output_text.replaceAll("\\u0062", "\u1017");
		output_text = output_text.replaceAll("\\u0063", "\u105A");
		output_text = output_text.replaceAll("\\u0064", "\u1012");
		output_text = output_text.replaceAll("\\u0065", "\u1031");
		output_text = output_text.replaceAll("\\u0066", "\u1016");
		output_text = output_text.replaceAll("\\u0067", "\u1002");
		output_text = output_text.replaceAll("\\u0068", "\u101F");
		output_text = output_text.replaceAll("\\u0069", "\u102D");
		output_text = output_text.replaceAll("\\u006A", "\u103A");
		output_text = output_text.replaceAll("\\u006B", "\u1000");
		output_text = output_text.replaceAll("\\u006C", "\u101C");
		output_text = output_text.replaceAll("\\u006D", "\u1019");
		output_text = output_text.replaceAll("\\u006E", "\u1014");
		output_text = output_text.replaceAll("\\u006F", "\u1036");
		output_text = output_text.replaceAll("\\u0070", "\u1015");
		output_text = output_text.replaceAll("\\u0071", "\u101E");
		output_text = output_text.replaceAll("\\u0072", "\u101B");
		output_text = output_text.replaceAll("\\u0073", "\u1005");
		output_text = output_text.replaceAll("\\u0074", "\u1010");
		output_text = output_text.replaceAll("\\u0075", "\u102F");
		output_text = output_text.replaceAll("\\u0076", "\u1018");
		output_text = output_text.replaceAll("\\u0077", "\u101D");
		output_text = output_text.replaceAll("\\u0078", "\u100A");
		output_text = output_text.replaceAll("\\u0079", "\u101A");
		output_text = output_text.replaceAll("\\u007A", "\u1007");
		output_text = output_text.replaceAll("\\u007B", "\u103C");
		output_text = output_text.replaceAll("\\u007C", "\u1039\u1013");
		output_text = output_text.replaceAll("\\u007D", "\u1030");
		output_text = output_text.replaceAll("\\u007E", "\u1039\u101C");
		output_text = output_text.replaceAll("\\u00C4", "\u1009\u1039\u1005");
		output_text = output_text.replaceAll("\\u00C7", "\u1023");
		output_text = output_text.replaceAll("\\u00C9", "\u100E");
		output_text = output_text.replaceAll("\\u00EE", "\u103C");
		output_text = output_text.replaceAll("\\u00EF", "\u103C");
		output_text = output_text.replaceAll("\\u2020", "\u104D");
		output_text = output_text.replaceAll("\\u00B0", "\u1037");

		output_text = output_text.replaceAll("\\u00A7", "\u103C\u102F");
		output_text = output_text.replaceAll("\\u2022", "\u103B\u103E");
		output_text = output_text.replaceAll("\\u00B6", "\u1009");
		output_text = output_text.replaceAll("\\u00AE", "\u103C\u102F");
		output_text = output_text.replaceAll("\\u00A9", "\u100D\u1039\u100E");
		output_text = output_text.replaceAll("\\u2122", "\u103D\u103E");
		output_text = output_text.replaceAll("\\u00B4", "\u100D");
		output_text = output_text.replaceAll("\\u00A8", "\u103E\u102F");
		output_text = output_text.replaceAll("\\u00B1", "\u103C\u103D");
		output_text = output_text.replaceAll("\\u00A5", "\u103C\u103D");
		output_text = output_text.replaceAll("\\u03BC", "\u1039\u1014");
		output_text = output_text.replaceAll("\\u00BA", "\u100B\u1039\u100B");
		output_text = output_text.replaceAll("\\u00AC", "\u103B");
		output_text = output_text.replaceAll("\\u0042", "\u1039\u1019");
		output_text = output_text.replaceAll("\\u00BB", "\u103E\u1030");
		output_text = output_text.replaceAll("\\u2026", "\u1024");
		output_text = output_text.replaceAll("\\u00C3", "\u103B\u103D");
		output_text = output_text.replaceAll("\\u0153", "\u1039\u1007\u103B");
		output_text = output_text.replaceAll("\\u2013", "\u1027");
		output_text = output_text.replaceAll("\\u2014", "\u102B\u103A");
		output_text = output_text.replaceAll("\\u201C", "\u1039\u105C");
		output_text = output_text.replaceAll("\\u201D", "\u1039\u105C");
		output_text = output_text.replaceAll("\\u2018", "\u105C");
		output_text = output_text.replaceAll("\\u2019", "\u105C");
		output_text = output_text.replaceAll("\\u0178", "\u1023");
		output_text = output_text.replaceAll("\\u2039", "\u1039\u1016");
		output_text = output_text.replaceAll("\\u203A", "\u1039\u1017");
		output_text = output_text.replaceAll("\\u2021", "\u1037");

		output_text = output_text.replaceAll("\\u2030", "\u100F\u1039\u100D");

		output_text = output_text.replaceAll("\\u00CB", "\u1028");
		output_text = output_text.replaceAll("\\u00CC",
				"\u1014\u1039\u1010\u103D");
		output_text = output_text.replaceAll("\\u00D4", "\u104E");
		output_text = output_text.replaceAll("\\u02C6", "\u104F");
		output_text = output_text.replaceAll("\\u02C9", "\u100F\u1039\u100F");
		output_text = output_text.replaceAll("\\u0080", "\u100C");
		output_text = output_text.replaceAll("\\u008E", "\u100A");
		output_text = output_text.replaceAll("\\u008F", "\u1009\u1039\u1007");
		output_text = output_text.replaceAll("\\u0090", "\u1039\u101F");
		output_text = output_text.replaceAll("\\u009D", "\u103C\u102F");
		output_text = output_text.replaceAll("\\u00A4", "\u1039\u1003");

		output_text = output_text.replaceAll("\\u201A", "\u2014");
		output_text = output_text.replaceAll("\\u002d", "\u103C");
		output_text = output_text.replaceAll("\\u00C6", "\u002C");
		output_text = output_text.replaceAll("\\u0192", "\u002f");
		output_text = output_text.replaceAll("\\u00C1", "\u2018");
		output_text = output_text.replaceAll("\\u00C2", "\u2019");
		output_text = output_text.replaceAll("\\u00BF", "\u201C");
		output_text = output_text.replaceAll("\\u00C0", "\u201D");
		output_text = output_text.replaceAll("\\u1025\\u103A", "\u1009\u103A");
		output_text = output_text.replaceAll("\\u00AA", "\u003D");
		output_text = output_text.replaceAll("\\u00A6", "\u003F");
		output_text = output_text.replaceAll("\\u00B3", "\u103E");
		output_text = output_text.replaceAll("\\u00B5", "\u1014");
		output_text = output_text.replaceAll("\\u00AF", "\u100F\u1039\u100F");

		output_text = output_text
				.replaceAll("(\\u105A\\u1037)", "\u1004\u1037"); // Mon&Bure
		output_text = output_text
				.replaceAll("(\\u105A\\u103B)", "\u1004\u103B"); // Mon&Bure
		output_text = output_text.replaceAll("(\\u103C\u105A)", "\u1004\u103C"); // Mon&Bure
		output_text = output_text
				.replaceAll("(\\u105A\\u103D)", "\u1004\u103D"); // Mon&Bure
		output_text = output_text
				.replaceAll("(\\u105A\\u103E)", "\u1004\u103E"); // Mon&Bure
		output_text = output_text.replaceAll(
				"\\u105A([\\u102B\\u102C]?)(\\u1037)", "\u1004\u102B\u1037"); // Mon&Bure
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])(\\u102C)\\u0056",
						"\u105A\u103A\u1039$1$2$3$4"); // kinizi i
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])\\u00AB",
				"\u105A\u103A\u1039$1$2$3\u1036"); // Kinzi ai
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])\\u2219",
				"\u105A\u103A\u1039$1$2$3\u1033"); // kinzi Mon ii
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103c)?)([\\u1000-\\u1021])\\u201E",
				"\u105A\u103A\u1039$1$2$3\u102E");
		output_text = output_text.replaceAll(
				"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])\\u00CA   ",
				"\u105A\u103A\u1039$1$2$3\u102D");

		// reoder
		output_text = output_text.replaceAll("(\\u103A)(\\u1037)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u102D)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1035)", "$2$1");
		//
		// Ra&HawayMu
		output_text = output_text.replaceAll(
				"(\\u103C)([\\u1000-\\u1021])((?:\\u1039[\\u1000-\\u1021])?)",
				"$2$3$1");
		output_text = output_text.replaceAll(
				"(\\u103C)(\\u103D)([\\u1000-\\u1021])", "$3$1$2");
		// reordering ra

		// output_text = output_text.replaceAll(
		// "(\u103E)?(\u103D)?([\u103B\u103C])   ", "$3$2$1");
		// reordering ra

		output_text = output_text.replaceAll(
				"(\\u103E)(\\u103D)([\\u103B\\u103C])   ", "$3$2$1");
		output_text = output_text.replaceAll("(\\u103E)([\\u103B\\u103C])   ",
				"$2$1");

		output_text = output_text.replaceAll("(\\u103D)([\\u103B\\u103C])   ",
				"$2$1");
		// Ra&HawayMu
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)([\\u1000-\\u1021])((?:\\u1039[\\u1000-\\u1021\\u105A\\u105C])?)((?:[\\u102D\\u102E\\u1032\\u1033\\u1034\\u1035])?)([\\u1036\\u1037\\u1038]{0,2})([\\u103B-\\u103C]{0,3})((?:[\\u102F\\u1030])?)([\\u1036\\u1037\\u1038]{0,2})((?:[\\u102D\\u102E\\u1032])?)",
						"$2$3$6$1$4$9$7$5$8");

		output_text = output_text.replaceAll("(\\u103A)(\\u1037)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1035)", "$2$1");
		output_text = output_text.replaceAll("(\\u1032)(\\u102F)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1033)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u102D)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u102E)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1033)", "$2$1");
		output_text = output_text.replaceAll("(\\u102F)(\\u1035)", "$2$1");
		output_text = output_text.replaceAll("(\\u1032)(\\u103D)", "$2$1");
		output_text = output_text.replaceAll("(\\u103A)(\\u103E)", "$2$1");
		output_text = output_text
				.replaceAll(
						"([\\u102D\\u102E\\u1032-\\u1036])([\\u105E\\u105F\\u1060\\u103D\\u103E])",
						"$2$1");
		output_text = output_text
				.replaceAll(
						"([\\u102D\\u102E\\u1032-\\u1035])((?:\\u1039[\\u1000-\\u1021\\u105A\\u105C])?)",
						"$2$1");
		output_text = output_text.replaceAll(
				"\\u1031([\\u103A\\u103B-\\u103E\\u105C-\\u105F\\u1060]+)",
				"$1\u1031");
		output_text = output_text.replaceAll(
				"\\u1031((?:\\u1039[\\u1000-\\u1021\\u105A\\u105C])?)",
				"$1\u1031");
		output_text = output_text.replaceAll("\\u1031([\\u105B\\u105D])",
				"$1\u1031");
		output_text = output_text.replaceAll("\\u1032\\u102F", "$2$1");
		return output_text;
	}
}
