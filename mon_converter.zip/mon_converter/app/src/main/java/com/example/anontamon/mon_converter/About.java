package com.example.anontamon.mon_converter;

import android.app.Activity;
import android.os.Bundle;

/**
 * This is just a place holder
 */
public class About extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);

	}
}
