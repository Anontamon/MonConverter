package com.example.anontamon.mon_converter;

public class MonToUni {

	public static String mon2uni(String input_text) {
		String output_text = input_text;
		output_text = output_text.replaceAll("\\u106a", "\u1009");
		output_text = output_text.replaceAll("\\u1025\\u102e", "\u1026");
		output_text = output_text.replaceAll("\\u106b", "\u100a");
		output_text = output_text.replaceAll("\\u1090", "\u101b");
		output_text = output_text.replaceAll("\\u1040", "\u1040");
		output_text = output_text.replaceAll("\\u108f", "\u1014");
		output_text = output_text.replaceAll("\\u1012", "\u1012");
		output_text = output_text.replaceAll("\\u105e", "\u1039\u105C");
		output_text = output_text.replaceAll("\\u105f", "\u1039\u1021");
		output_text = output_text.replaceAll("\\u103f", "\u105f");
		output_text = output_text.replaceAll("\\u1013", "\u1013");
		output_text = output_text.replaceAll("\\u103e", "\u105e");
		output_text = output_text.replaceAll("\\u103d", "\u103e");
		output_text = output_text.replaceAll("\\u1087", "\u103e");
		output_text = output_text.replaceAll("\\u103c", "\u103d");
		output_text = output_text.replaceAll("\\u103b", "\u103c");
		output_text = output_text.replaceAll("\\u107e", "\u103c");
		output_text = output_text.replaceAll("\\u107f", "\u103c");
		output_text = output_text.replaceAll("\\u1080", "\u103c");
		output_text = output_text.replaceAll("\\u1081", "\u103c");
		output_text = output_text.replaceAll("\\u1082", "\u103c");
		output_text = output_text.replaceAll("\\u1083", "\u103c");
		output_text = output_text.replaceAll("\\u1084", "\u103c");
		output_text = output_text.replaceAll("\\u103a", "\u103b");
		output_text = output_text.replaceAll("\\u107d", "\u103b");
		output_text = output_text.replaceAll("\\u108a", "\u103d\u103e");
		output_text = output_text.replaceAll("\\u105a", "\u102b\u103a");
		output_text = output_text.replaceAll("\\u108e", "\u102d\u1036");
		output_text = output_text.replaceAll("\\u1033", "\u102f");
		output_text = output_text.replaceAll("\\u1034", "\u1030");
		output_text = output_text.replaceAll("\\u1088", "\u103e\u102f");
		output_text = output_text.replaceAll("\\u1089", "\u103e\u1030");
		output_text = output_text.replaceAll("\\u1039", "\u103a");
		output_text = output_text.replaceAll("\\u1094", "\u1037");
		output_text = output_text.replaceAll("\\u1095", "\u1037");
		output_text = output_text.replaceAll("\\u1064", "\u1004\u103a\u1039");
		output_text = output_text.replaceAll("\\u108B",
				"\u1004\u103a\u1039\u102D");
		output_text = output_text.replaceAll("\\u108C",
				"\u1004\u103a\u1039\u102E");
		output_text = output_text.replaceAll("\\u108D",
				"\u1004\u103a\u1039\u1036");
		output_text = output_text.replaceAll("\\u109A",
				"\u1004\u103a\u1039\u1033");

		output_text = output_text.replaceAll("\\u104e",
				"\u104e\u1004\u103a\u1038");
		output_text = output_text.replaceAll("\\u1086", "\u103f");
		output_text = output_text.replaceAll("\\u1060", "\u1039\u1000");
		output_text = output_text.replaceAll("\\u1061", "\u1039\u1001");
		output_text = output_text.replaceAll("\\u1062", "\u1039\u1002");
		output_text = output_text.replaceAll("\\u1063", "\u1039\u1003");
		output_text = output_text.replaceAll("\\u1065", "\u1039\u1005");
		output_text = output_text.replaceAll("\\u1066", "\u1039\u1006");
		output_text = output_text.replaceAll("\\u1067", "\u1039\u1006");
		output_text = output_text.replaceAll("\\u1068", "\u1039\u1007");
		output_text = output_text.replaceAll("\\u1069", "\u1039\u1008");
		output_text = output_text.replaceAll("\\u106c", "\u1039\u100b");
		output_text = output_text.replaceAll("\\u1070", "\u1039\u100f");
		output_text = output_text.replaceAll("\\u1071", "\u1039\u1010");
		output_text = output_text.replaceAll("\\u1072", "\u1039\u1010");
		output_text = output_text.replaceAll("\\u1073", "\u1039\u1011");
		output_text = output_text.replaceAll("\\u1074", "\u1039\u1011");
		output_text = output_text.replaceAll("\\u1075", "\u1039\u1012");
		output_text = output_text.replaceAll("\\u1076", "\u1039\u1013");
		output_text = output_text.replaceAll("\\u1077", "\u1039\u1014");
		output_text = output_text.replaceAll("\\u1078", "\u1039\u1015");
		output_text = output_text.replaceAll("\\u1079", "\u1039\u1016");
		output_text = output_text.replaceAll("\\u107a", "\u1039\u1017");
		output_text = output_text.replaceAll("\\u107b", "\u1039\u1018");
		output_text = output_text.replaceAll("\\u1093", "\u1039\u1018");
		output_text = output_text.replaceAll("\\u107c", "\u1039\u1019");
		output_text = output_text.replaceAll("\\u1085", "\u1039\u101c");
		output_text = output_text.replaceAll("\\u106d", "\u1039\u100c");
		output_text = output_text.replaceAll("\\u1091", "\u100f\u1039\u100d");
		output_text = output_text.replaceAll("\\u1092", "\u100b\u1039\u100c");
		output_text = output_text.replaceAll("\\u1097", "\u100b\u1039\u100b");
		output_text = output_text.replaceAll("\\u106f", "\u100d\u1039\u100e");
		output_text = output_text.replaceAll("\\u106e", "\u100d\u1039\u100d");
		output_text = output_text.replaceAll("\\u105d", "\u1039\u101e");
		output_text = output_text.replaceAll("\\u105b", "\u1039\u105a");
		output_text = output_text.replaceAll("\\u105c", "\u1060");
		output_text = output_text.replaceAll("\\u1050", "\u105c");
		output_text = output_text.replaceAll("\\u1022", "\u105d");
		output_text = output_text.replaceAll("\\u1086", "\u103f");
		output_text = output_text.replaceAll("\\u1035", "\u1034");
		output_text = output_text.replaceAll("\\u1098", "\u1033");
		output_text = output_text.replaceAll("\\u109d", "\u1035");
		output_text = output_text.replaceAll("\\u109b", "\u1039\u100a");
		output_text = output_text.replaceAll("\\u109c", "\u1039\u100d");
		output_text = output_text.replaceAll("\\u1099", "\u102d\u1032");
		output_text = output_text.replaceAll("\\u1088", "\u103e\u102f");
		output_text = output_text.replaceAll("\\u1089", "\u103e\u1030");
		output_text = output_text.replaceAll("\\u1099", "\u102d\u1032");
		output_text = output_text.replaceAll("\\u1004", "\u105a");
		output_text = output_text.replaceAll("\\u102D\\u102D", "\u102D");
		output_text = output_text.replaceAll("\\u102E\\u102E", "\u102E");
		output_text = output_text.replaceAll("\\u102F\\u102F", "\u102F");
		output_text = output_text.replaceAll("\\u1030\\u1030", "\u1030");
		output_text = output_text.replaceAll("\\u1032\\u1032", "\u1032");
		output_text = output_text.replaceAll("\\u1098\\u1098", "\u1033");
		output_text = output_text.replaceAll("\\u1035\\u1035", "\u1034");
		output_text = output_text.replaceAll("\\u1036\\u1036", "\u1036");
		// output_text = output_text.replaceAll("\\u1039\\u1039", "\u103A");
		// output_text = output_text.replaceAll("\\u103A\\u103A", "\u103A");
		output_text = output_text.replaceAll("\\u1096", "\u1039\u1010\u103d");

		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u102C)?)\\u1064",
						"\u1064$1$2$3");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u1064",
						"\u105A\u103A\u1039$1$2$3$4");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u105A\\u103A\\u1039",
						"\u105A\u103A\u1039$1$2$3$4");
		output_text = output_text.replaceAll(
				"\\u1025(?=[\\u103A\\u1039\\u102C])", "\u1009");
		output_text = output_text.replaceAll(
				"\\u105A(?=[\\u102B\\u1037\\u103E\\u103D\\u103B\\u103C])",
				"\u1004");
		output_text = output_text.replaceAll("\\u103d\\u103b", "\u103b\u103d");
		output_text = output_text.replaceAll("\\u103e\\u103d", "\u103d\u103e");

		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u1064",
						"\u1064$1$2$3$4");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u108B",
						"\u1064$1$2$3$4\u102D");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u108C",
						"\u1064$1$2$3$4\u102E");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u108D",
						"\u1064$1$2$3$4\u1036");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u109A",
						"\u1064$1$2$3$4\u1033");

		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u1064",
						"\u1064$1$2$3");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u108B",
						"\u1064$1$2$3\u102D");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u108C",
						"\u1064$1$2$3\u102E");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u108D",
						"\u1064$1$2$3\u1036");
		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)((?:\\u103C)?)([\\u1000-\\u1021])((?:\\u103B)?)\\u109A",
						"\u1064$1$2$3\u1033");

		output_text = output_text.replaceAll("\\u103a\\u1021", "\u1039\u1021");
		output_text = output_text.replaceAll("\\u103a\\u1060", "\u1039\u105c");
		output_text = output_text.replaceAll("\\u103e\\u103b", "\u103b\u103e");
		output_text = output_text.replaceAll(
				"(\\u103C)([\\u1000-\\u1021])((?:\\u1039[\\u1000-\\u1021])?)",
				"$2$3$1");
		output_text = output_text.replaceAll(
				"(\\u103d)(\u103d)([\\u103b\\u103c])", "$3$2$1");
		output_text = output_text.replaceAll("(\\u103d)([\\u103b\\u103c])",
				"$2$1");
		output_text = output_text
				.replaceAll(
						"(\\u1047)(?=[\\u1000-\\u101c\\u101e-\\u102a\\u102c\\u102e-\\u103d\\u104c-\\u109f\\s])",
						"\u101b");
		output_text = output_text.replaceAll("(\\u1031)(\\u1040)", "$2$1");
		output_text = output_text.replaceAll("(\\u105a\\u1039\\u105a)",
				"\u105a");
		output_text = output_text.replaceAll(
				"(\\u1040)(?=[\\u102b\\u102d-\\u103e])", "\u101d");
		output_text = output_text
				.replaceAll("(\\u1039)(?=[\\u1021])", "\u103a");

		output_text = output_text
				.replaceAll(
						"((?:\\u1031)?)([\\u1000-\\u1021\\u103f])((?:\\u1039[\\u1000-\\u1021\\u1096])?)((?:[\\u102d\\u102e\\u1032])?)([\\u1036\\u1037\\u1038]{0,2})([\\u103b-\\u103d]{0,3})((?:[\\u102f\\u1030])?)([\\u1036\\u1037\\u1038]{0,2})((?:[\\u102d\\u102e\\u1032])?)",
						"$2$3$6$1$4$9$7$5$8");
		output_text = output_text.replaceAll("\\u1036\\u102f", "\u102f\u1036");

		output_text = output_text.replaceAll("(\\u102f)(\\u1035)", "$2$1");
		output_text = output_text.replaceAll("(\\u1032)(\\u102f)", "$2$1");
		output_text = output_text.replaceAll("(\\u102f)(\\u1033)", "$2$1");
		output_text = output_text.replaceAll("(\\u102f)(\\u102d)", "$2$1");
		output_text = output_text.replaceAll("(\\u102f)(\\u102e)", "$2$1");
		output_text = output_text.replaceAll("(\\u102f)(\\u1033)", "$2$1");
		output_text = output_text.replaceAll("(\\u102f)(\\u1035)", "$2$1");
		output_text = output_text.replaceAll("(\\u1032)(\\u103d)", "$2$1");
		output_text = output_text.replaceAll("(\\u103a)(\\u103e)", "$2$1");
		output_text = output_text
				.replaceAll(
						"([\\u102d\\u102e\\u1032-\\u1036])([\\u105e\\u105f\\u1060\\u103d\\u103e])",
						"$2$1");
		output_text = output_text
				.replaceAll(
						"([\\u102d\\u102e\\u1032-\\u1035])(\\u1039[\\u1000-\\u1021\\u105a\\u105c])",
						"$2$1");
		output_text = output_text.replaceAll(
				"\\u1031([\\u103a\\u103b-\\u103e\\u105c-\\u105f\\u1060]+)",
				"$1\u1031");
		output_text = output_text.replaceAll(
				"([\\u1000-\\u1021\\u105a\\u105c])(\\u103e)(\\u103a)(\\u1031)",
				"$1$2$4$3");
		output_text = output_text.replaceAll(
				"\\u1031(\\u1039[\\u1000-\\u1021\\u105a\\u105c])", "$1\u1031");
		output_text = output_text
				.replaceAll(
						"([\\u1000-\\u1021\\u105a\\u105c])(\\u103c)(\\u105a\\u103a\\u1039)",
						"$3$1$2");
		output_text = output_text.replaceAll("\\u1031([\\u105b\\u105d])",
				"$1\u1031");
		output_text = output_text.replaceAll("(\\u103a)(\\u1037)", "$2$1");

		return output_text;
	}
}