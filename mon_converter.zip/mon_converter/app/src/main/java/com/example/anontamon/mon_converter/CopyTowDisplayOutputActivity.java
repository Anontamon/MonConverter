package com.example.anontamon.mon_converter;

import com.example.anontamon.mon_converter.R;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.ClipboardManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("CutPasteId")
public class CopyTowDisplayOutputActivity extends Activity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_display_output);

		Button DisplayCopyButton = (Button) findViewById(R.id.displayCopyButton);
		DisplayCopyButton.setOnClickListener(new View.OnClickListener() {
			@SuppressWarnings("deprecation")
			public void onClick(View v) {
				EditText OutputTextArea = (EditText) findViewById(R.id.outputText);
				String OutputTextData = OutputTextArea.getText().toString();
				ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
				clipboard.setText(OutputTextData);

				Context context = getApplicationContext();
				CharSequence text = "Text has loaded into clipboard";
				int duration = Toast.LENGTH_LONG;

				Toast toast = Toast.makeText(context, text, duration);
				toast.show();

			}
		});

		EditText OutputTextArea = (EditText) findViewById(R.id.outputText);
		Intent intent = getIntent();
		String output_text = intent.getStringExtra(MonConverter.OUTPUT_TEXT);
		OutputTextArea.setText(output_text);

		final Typeface typeface = Typeface.createFromAsset(getAssets(),
				"fonts/UniMon 2012 00.ttf");
		final EditText editTextNormal = (EditText) findViewById(R.id.outputText);
		editTextNormal.setTypeface(typeface);
	}
}
